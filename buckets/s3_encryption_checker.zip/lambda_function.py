import boto3
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    buckets = s3.list_buckets()

    for bucket in buckets['Buckets']:
        bucket_name = bucket['Name']
        try:
            encryption = s3.get_bucket_encryption(Bucket=bucket_name)
            logger.info(f"Bucket {bucket_name} is encrypted with {encryption['ServerSideEncryptionConfiguration']['Rules'][0]['ApplyServerSideEncryptionByDefault']['SSEAlgorithm']}.")
        except s3.exceptions.ClientError as e:
            if e.response['Error']['Code'] == 'ServerSideEncryptionConfigurationNotFoundError':
                logger.warning(f"Bucket {bucket_name} is NOT encrypted. Enforcing encryption...")
                enforce_encryption(bucket_name, s3)
            else:
                logger.error(f"Failed to check encryption for bucket {bucket_name}: {e}")
    return {"statusCode": 200, "body": "Encryption check complete."}

def enforce_encryption(bucket_name, s3):
    try:
        s3.put_bucket_encryption(
            Bucket=bucket_name,
            ServerSideEncryptionConfiguration={
                'Rules': [
                    {
                        'ApplyServerSideEncryptionByDefault': {
                            'SSEAlgorithm': 'AES256'
                        }
                    }
                ]
            }
        )
        logger.info(f"Encryption enforced for bucket {bucket_name}.")
    except Exception as e:
        logger.error(f"Failed to enforce encryption for bucket {bucket_name}: {e}")
